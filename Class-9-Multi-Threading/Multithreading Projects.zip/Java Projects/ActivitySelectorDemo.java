import java.util.Random;
import java.util.Scanner;

class ActivitySelector {
    private String selectedActivity;
    private boolean isActivitySelected = false;
    private boolean isSpinnerReady = false;
    private Object lock = new Object();

    // Method to select an activity
    void selectActivity(String activity) {
        synchronized (lock) {
            selectedActivity = activity;
            isActivitySelected = true;
            lock.notify(); // Notify the waiting thread that an activity is selected
        }
    }

    // Method to spin the lucky spinner and get a random activity
    void spinLuckySpinner() {
        synchronized (lock) {
            Random random = new Random();
            String[] activities = {"sports", "swimming", "study", "running", "gaming"};
            int randomIndex = random.nextInt(activities.length);
            selectedActivity = activities[randomIndex];
            isActivitySelected = true;
            lock.notify(); // Notify the waiting thread that an activity is selected
        }
    }

    // Method to display the selected activity
    void displaySelectedActivity() {
        synchronized (lock) {
            while (!isActivitySelected) {
                try {
                    lock.wait(); // Wait for an activity to be selected
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
            System.out.println("Suggested activity: " + selectedActivity);
        }
    }
}

public class ActivitySelectorDemo {
    public static void main(String[] args) {
        ActivitySelector activitySelector = new ActivitySelector();

        // Create a thread to display the selected activity
        Thread displayThread = new Thread(() -> {
            activitySelector.displaySelectedActivity();
        });
        displayThread.start();

        Scanner scanner = new Scanner(System.in);

        // Main loop for user input
        while (true) {
            System.out.print("Choose an activity (sports, swimming, study, running, gaming), or type 'spin' for luckyspinner: ");
            String input = scanner.nextLine();

            if (input.equalsIgnoreCase("spin")) {
                activitySelector.spinLuckySpinner();
            } else if (isValidActivity(input)) {
                activitySelector.selectActivity(input);
            } else {
                System.out.println("Invalid input. Please try again.");
            }
        }
    }

    // Method to check if the input is a valid activity
    private static boolean isValidActivity(String input) {
        String[] validActivities = {"sports", "swimming", "study", "running", "gaming"};
        for (String activity : validActivities) {
            if (activity.equalsIgnoreCase(input)) {
                return true;
            }
        }
        return false;
    }
}
