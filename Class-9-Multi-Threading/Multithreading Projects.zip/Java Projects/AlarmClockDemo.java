import java.util.ArrayList;
import java.util.List;

class AlarmClock {
    private List<Thread> alarms = new ArrayList<>();

    // Add a new alarm
    void setAlarm(int hours, int minutes) {
        AlarmThread alarmThread = new AlarmThread(hours, minutes);
        Thread thread = new Thread(alarmThread);
        alarms.add(thread);
        thread.start();
        System.out.println("Alarm set for " + hours + ":" + minutes);
    }

    // Stop all alarms
    void stopAllAlarms() {
        for (Thread alarm : alarms) {
            alarm.interrupt();
        }
        alarms.clear();
        System.out.println("All alarms stopped.");
    }
}

class AlarmThread implements Runnable {
    private int hours;
    private int minutes;

    AlarmThread(int hours, int minutes) {
        this.hours = hours;
        this.minutes = minutes;
    }

    @Override
    public void run() {
        try {
            while (true) {
                // Get the current time
                int currentHours = java.time.LocalTime.now().getHour();
                int currentMinutes = java.time.LocalTime.now().getMinute();

                // Check if the alarm time has been reached
                if (currentHours == hours && currentMinutes == minutes) {
                    System.out.println("Alarm triggered at " + currentHours + ":" + currentMinutes);
                    break;
                }

                Thread.sleep(1000); // Sleep for 1 second before checking again
            }
        } catch (InterruptedException e) {
            System.out.println("Alarm interrupted.");
        }
    }
}

public class AlarmClockDemo {
    public static void main(String[] args) {
        AlarmClock alarmClock = new AlarmClock();

        // Set two alarms
        alarmClock.setAlarm(9, 0); // 9:00 AM
        alarmClock.setAlarm(13, 30); // 1:30 PM

        // Allow time for the alarms to trigger
        try {
            Thread.sleep(10000); // Sleep for 10 seconds
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        // Stop all alarms
        alarmClock.stopAllAlarms();
    }
}
