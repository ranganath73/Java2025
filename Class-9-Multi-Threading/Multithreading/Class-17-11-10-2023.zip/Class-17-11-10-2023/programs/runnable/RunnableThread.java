public class RunnableThread implements Runnable
{
    public void run()
    {
        System.out.println("From Run method");
    }
}