import { Component } from '@angular/core';

@Component({
  selector: 'app-expense-entry',
  imports: [],
  templateUrl: './expense-entry.component.html',
  styleUrl: './expense-entry.component.css'
})
export class ExpenseEntryComponent {
  

  title = "Expense Entry";
}
