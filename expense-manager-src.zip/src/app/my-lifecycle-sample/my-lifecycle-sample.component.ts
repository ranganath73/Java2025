import { Component, OnChanges, OnInit, SimpleChanges } from '@angular/core';

@Component({
  selector: 'app-my-lifecycle-sample',
  imports: [],
  templateUrl: './my-lifecycle-sample.component.html',
  styleUrl: './my-lifecycle-sample.component.css'
})
export class MyLifecycleSampleComponent implements OnChanges, OnInit{

    ngOnChanges(changes: SimpleChanges): void {
      console.log("Change Detection.")
    }

    ngOnInit(): void {
      console.log("Initialization of component / directive");
    }

    ngDoCheck() {
      console.log("Custom change detection");
    }

    ngAfterContentInit() {
      console.log("Content initialization");
    }

    ngAfterContentChecked() {
      console.log("Checking changes in content")
    }

    ngAfterViewInit() {
      console.log("View initialization");
    }

    ngAfterViewChecked() {
      console.log("Checking changes in views");
    }

    ngOnDestroy() {
      console.log("Destruction of component / directive");
    }
}
