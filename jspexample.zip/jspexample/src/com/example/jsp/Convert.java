package com.example.jsp;

public class Convert {
	
	public static String convertToUpper(String data) {
		return data.toUpperCase();
	}

}
