import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { SalesPersonListComponent } from './sales-person-list/sales-person-list.component';
// import { SalesPersonComponent } from './sales-person-list/sales-person/sales-person.component';
import { SalesPerson } from './sales-person-list/sales-person';

@NgModule({
  declarations: [
    AppComponent,
    SalesPersonListComponent,
    // SalesPerson
  ],
  imports: [
    BrowserModule,
    AppRoutingModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
