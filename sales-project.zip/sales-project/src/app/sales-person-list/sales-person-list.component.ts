import { Component } from '@angular/core';
import { SalesPerson } from './sales-person';

@Component({
  selector: 'app-sales-person-list',
  standalone: false,
  templateUrl: './sales-person-list.component.html',
  styleUrl: './sales-person-list.component.css'
})
export class SalesPersonListComponent {

  // create an array of objects
  salesPersonList: SalesPerson[] = [
    new SalesPerson("Anup", "Kumar", "anup@net.in", 50000),
    new SalesPerson("John", "Doe", "john@net.in", 40000),
    new SalesPerson("Eddy", "Murphy", "eddy@net.in", 90000),
    new SalesPerson("Jakie", "Chan", "jakie@net.in", 60000)
  ]
}
