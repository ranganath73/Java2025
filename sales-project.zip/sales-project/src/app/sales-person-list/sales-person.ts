export class SalesPerson {

    constructor(public firstName: string,
                public lastName: string,
                public email: string,
                public salesVolume: number) {
                    
                }
}
